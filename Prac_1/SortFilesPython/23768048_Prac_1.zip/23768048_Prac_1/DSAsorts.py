#
# Data Structures and Algorithms COMP1002
#
# Python file to hold all sorting methods
#


def bubbleSort(A):
    """
    bubbleSort - sorts an array in place using the bubble sort algorithm
    """
    num = len(A)
    swapped = True
    i = 0
    while i < num and swapped:
        swapped = False
        for j in range(0, num - i - 1):
            if A[j] > A[j+1]:
                temp = A[j]
                A[j] = A[j+1]
                A[j+1] = temp
                swapped = True
        i += 1
    print(A)
    return A


def insertionSort(A):
    """
    insertionSort - sorts an array in place using the insertion sort algorithm
    """
    num = len(A)
    for i in range(1, num):
        j = i
        while j > 0 and A[j-1] > A[j]:
            temp = A[j]
            A[j] = A[j-1]
            A[j-1] = temp
            j -= 1
    return A


def selectionSort(A):
    """
    selectionSort - sorts an array in place using the selection sort algorithm
    """
    num = len(A)
    for i in range(num-1):
        min_index = i
        for j in range(i+1, num):
            if A[j] < A[min_index]:
                min_index = j
        temp = A[min_index]
        A[min_index] = A[i]
        A[i] = temp
    return A


def mergeSort(A):
    """ 
    mergeSort - front-end for kick-starting the recursive algorithm
    """
    ...


def mergeSortRecurse(A, leftIdx, rightIdx):
    ...


def merge(A, leftIdx, midIdx, rightIdx):
    ...


def quickSort(A):
    """ quickSort - front-end for kick-starting the recursive algorithm
    """
    ...


def quickSortRecurse(A, leftIdx, rightIdx):
    ...


def doPartitioning(A, leftIdx, rightIdx, pivotIdx):
    ...
